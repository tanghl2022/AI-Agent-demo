import asyncio

from fastapi import (
    APIRouter,
    Depends,
)

from fastapi.responses import (
    StreamingResponse,
)

from wms_agent.events.event_types import (
    AgentEventType,
)

from wms_agent.events.event_publisher import (
    AgentEventPublisher,
)

from wms_agent.events.sse_encoder import (
    encode_sse,
)


router = APIRouter(
    prefix="/api/agent",
    tags=["WMS Agent Stream"],
)


_agent_service = None


def set_stream_agent_service(
    service,
):
    global _agent_service

    _agent_service = service


def get_stream_agent_service():

    if _agent_service is None:

        raise RuntimeError(
            "AgentService尚未初始化"
        )

    return _agent_service


@router.post(
    "/chat/stream"
)
async def agent_chat_stream(
    request,
    service=Depends(
        get_stream_agent_service
    ),
):

    async def stream():

        publisher = (
            AgentEventPublisher(
                request_id=
                    request.request_id,
                conversation_id=
                    request.conversation_id,
            )
        )

        async def execute_agent():

            try:

                await publisher.publish(
                    AgentEventType
                    .AGENT_START,
                    node=
                        "agent_main",
                    status=
                        "RUNNING",
                    data={
                        "message":
                            request.message
                    },
                )

                result = await service.chat(
                    conversation_id=
                        request.conversation_id,
                    message=
                        request.message,
                    publisher=
                        publisher,
                )

                await publisher.publish(
                    AgentEventType.DONE,
                    node=
                        "agent_main",
                    status=
                        result.get(
                            "status"
                        ),
                    workflow_instance_id=
                        result.get(
                            "workflow_instance_id"
                        ),
                    data={
                        "answer":
                            result.get(
                                "answer"
                            )
                    },
                )

            except Exception as exc:

                await publisher.publish(
                    AgentEventType
                    .SYSTEM_FAILED,
                    node=
                        "agent_main",
                    status=
                        "SYSTEM_FAILED",
                    data={
                        "message":
                            str(exc)
                    },
                )

            finally:

                await publisher.close()

        task = asyncio.create_task(
            execute_agent()
        )

        try:

            while True:

                event = (
                    await publisher
                    .queue.get()
                )

                if event is None:
                    break

                yield encode_sse(
                    event
                )

        finally:

            if not task.done():
                task.cancel()

    return StreamingResponse(
        stream(),
        media_type=
            "text/event-stream",
        headers={
            "Cache-Control":
                "no-cache",

            "Connection":
                "keep-alive",
        },
    )