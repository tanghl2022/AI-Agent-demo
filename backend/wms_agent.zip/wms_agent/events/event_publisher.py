import asyncio
import uuid

from wms_agent.events.agent_event import (
    AgentEvent,
)

from wms_agent.events.event_types import (
    AgentEventType,
)


class AgentEventPublisher:

    def __init__(
        self,
        request_id: str,
        conversation_id: str,
    ):

        self.request_id = (
            request_id
        )

        self.conversation_id = (
            conversation_id
        )

        self.queue = asyncio.Queue()

        self.sequence = 0

    async def publish(
        self,
        event_type: AgentEventType,
        *,
        node: str | None = None,
        status: str | None = None,
        workflow_instance_id:
            str | None = None,
        data: dict | None = None,
    ):

        self.sequence += 1

        event = AgentEvent(
            event_id=str(
                uuid.uuid4()
            ),
            request_id=
                self.request_id,
            conversation_id=
                self.conversation_id,
            workflow_instance_id=
                workflow_instance_id,
            event_type=
                event_type,
            node=
                node,
            status=
                status,
            sequence=
                self.sequence,
            data=
                data or {},
        )

        await self.queue.put(
            event
        )

    async def close(
        self,
    ):
        """
        使用None作为内部队列结束标志。
        """

        await self.queue.put(
            None
        )