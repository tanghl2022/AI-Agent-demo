import json

from wms_agent.events.agent_event import (
    AgentEvent,
)


def encode_sse(
    event: AgentEvent,
) -> str:

    payload = (
        event.model_dump(
            by_alias=True,
            mode="json",
        )
    )

    return (
        f"event: "
        f"{event.event_type.value}\n"
        f"data: "
        f"{json.dumps(payload, ensure_ascii=False)}\n\n"
    )