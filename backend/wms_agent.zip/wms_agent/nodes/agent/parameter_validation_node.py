from wms_agent.models.agent_state import (
    AgentState,
)


def validate_agent_parameters(
    state: AgentState,
) -> dict:

    intent = state.get(
        "intent"
    )

    material_code = state.get(
        "material_code"
    )

    quantity = state.get(
        "quantity"
    )

    # ========================================================
    # QUERY_STOCK
    # ========================================================

    if intent == "QUERY_STOCK":

        if not material_code:

            return {
                "status":
                    "CLARIFICATION_REQUIRED",

                "answer":
                    "请告诉我需要查询库存的物料编码。",

                "pending_intent":
                    "QUERY_STOCK",

                "missing_parameters":
                    ["material_code"],
            }

        return {
            "status":
                "RUNNING",

            "answer":
                "",

            "pending_intent":
                None,

            "missing_parameters":
                [],
        }

    # ========================================================
    # QUERY_LOCATION
    # ========================================================

    if intent == "QUERY_LOCATION":

        if not material_code:

            return {
                "status":
                    "CLARIFICATION_REQUIRED",

                "answer":
                    "请告诉我需要查询库位的物料编码。",

                "pending_intent":
                    "QUERY_LOCATION",

                "missing_parameters":
                    ["material_code"],
            }

        return {
            "status":
                "RUNNING",

            "answer":
                "",

            "pending_intent":
                None,

            "missing_parameters":
                [],
        }

    # ========================================================
    # FREEZE_INVENTORY
    # ========================================================

    if intent == "FREEZE_INVENTORY":

        missing = []

        if not material_code:
            missing.append(
                "material_code"
            )

        if quantity is None:
            missing.append(
                "quantity"
            )

        if quantity is not None:
            if quantity <= 0:

                return {
                    "status":
                        "CLARIFICATION_REQUIRED",

                    "answer":
                        "冻结数量必须大于0，请重新输入。",

                    "pending_intent":
                        "FREEZE_INVENTORY",

                    "missing_parameters":
                        ["quantity"],

                    # 清除错误数量
                    "quantity":
                        None,
                }

        if missing:

            if (
                missing
                ==
                ["material_code"]
            ):

                answer = (
                    "请告诉我需要冻结库存的物料编码。"
                )

            elif (
                missing
                ==
                ["quantity"]
            ):

                answer = (
                    f"你希望冻结 "
                    f"{material_code} "
                    f"多少数量？"
                )

            else:

                answer = (
                    "请告诉我需要冻结的"
                    "物料编码和冻结数量。"
                )

            return {
                "status":
                    "CLARIFICATION_REQUIRED",

                "answer":
                    answer,

                "pending_intent":
                    "FREEZE_INVENTORY",

                "missing_parameters":
                    missing,
            }

        return {
            "status":
                "RUNNING",

            "answer":
                "",

            "pending_intent":
                None,

            "missing_parameters":
                [],
        }

    return {
        "status":
            "UNKNOWN",

        "answer":
            "当前请求无法匹配支持的WMS业务能力。",

        "pending_intent":
            None,

        "missing_parameters":
            [],
    }