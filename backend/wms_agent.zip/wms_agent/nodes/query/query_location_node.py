from typing import Any

from wms_agent.models.agent_state import (
    AgentState,
)


def create_query_location_node(
    location_query_client: Any,
):
    """
    创建库位查询节点。
    """

    async def query_location_node(
        state: AgentState,
    ) -> dict:

        material_code = state.get(
            "material_code"
        )

        if not material_code:

            return {
                "status":
                    "CLARIFICATION_REQUIRED",

                "answer":
                    "请告诉我需要查询库位的物料编码。",

                "active_workflow":
                    None,
            }

        # ----------------------------------------------------
        # 查询WMS
        # ----------------------------------------------------

        result = (
            await location_query_client
            .query_locations(
                material_code
            )
        )

        # ----------------------------------------------------
        # 没有库存库位
        # ----------------------------------------------------

        if not result.locations:

            return {
                "status": "SUCCESS",

                "answer":
                    f"当前没有查询到物料 "
                    f"{result.material_code} 的库存库位。",

                "active_workflow":
                    None,
            }

        # ----------------------------------------------------
        # 格式化库位结果
        # ----------------------------------------------------

        location_text = "；".join(
            [
                (
                    f"{item.location_code}"
                    f"：{item.quantity}"
                )
                for item in result.locations
            ]
        )

        answer = (
            f"物料 {result.material_code} "
            f"当前所在库位：{location_text}。"
        )

        return {
            "status": "SUCCESS",

            "answer": answer,

            "active_workflow": None,
        }

    return query_location_node