import time

from wms_agent.events.event_types import (
    AgentEventType,
)


def create_query_stock_node(
    inventory_query_client,
    event_publisher=None,
):

    async def query_stock_node(
        state,
    ):

        material_code = (
            state["material_code"]
        )

        start = time.perf_counter()

        if event_publisher:

            await event_publisher.publish(
                AgentEventType.TOOL_START,
                node=
                    "query_stock",
                status=
                    "RUNNING",
                data={
                    "tool":
                        "query_stock",

                    "materialCode":
                        material_code,
                },
            )

        result = (
            await inventory_query_client
            .query_stock(
                material_code
            )
        )

        duration_ms = int(
            (
                time.perf_counter()
                -
                start
            )
            * 1000
        )

        if event_publisher:

            await event_publisher.publish(
                AgentEventType.TOOL_END,
                node=
                    "query_stock",
                status=
                    "SUCCESS",
                data={
                    "tool":
                        "query_stock",

                    "durationMs":
                        duration_ms,

                    "materialCode":
                        material_code,

                    "availableQty":
                        result.available_qty,
                },
            )

        answer = (
            f"物料 "
            f"{result.material_code} "
            f"当前总库存"
            f"{result.total_qty}，"
            f"已预占"
            f"{result.reserved_qty}，"
            f"已冻结"
            f"{result.frozen_qty}，"
            f"可用库存"
            f"{result.available_qty}。"
        )

        return {
            "status":
                "SUCCESS",

            "answer":
                answer,

            "active_workflow":
                None,
        }

    return query_stock_node